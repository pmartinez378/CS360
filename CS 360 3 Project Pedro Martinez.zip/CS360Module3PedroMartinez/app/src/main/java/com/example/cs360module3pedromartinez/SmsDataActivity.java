package com.example.cs360module3pedromartinez;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.database.Cursor;

import java.util.ArrayList;

public class SmsDataActivity extends AppCompatActivity implements OnDataItemSelectedListener {

    private EditText phoneNumberEditText;
    private EditText messageEditText;
    private Button sendSmsButton;
    private RecyclerView dataRecyclerView;
    private DataAdapter dataAdapter;
    private ArrayList<String> dataList;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_data);

        // Initialize UI elements
        phoneNumberEditText = findViewById(R.id.phoneNumberEditText);
        messageEditText = findViewById(R.id.messageEditText);
        sendSmsButton = findViewById(R.id.sendSmsButton);
        dataRecyclerView = findViewById(R.id.dataRecyclerView);

        // Initialize database helper
        dbHelper = new DBHelper(this);

        // Set up data list and adapter, pass 'this' as the OnDataItemSelectedListener
        dataList = new ArrayList<>();
        dataAdapter = new DataAdapter(dataList, dbHelper, this);

        // Set up RecyclerView with GridLayoutManager
        dataRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));  // 2 columns for grid layout
        dataRecyclerView.setAdapter(dataAdapter);

        // Load data from database to display in the RecyclerView
        loadDataFromDatabase();

        // Set up the click listener for the Send SMS button
        sendSmsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phoneNumber = phoneNumberEditText.getText().toString().trim();
                String message = messageEditText.getText().toString().trim();

                if (!phoneNumber.isEmpty() && !message.isEmpty()) {
                    // Send SMS logic
                    Toast.makeText(SmsDataActivity.this, "SMS sent to " + phoneNumber, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(SmsDataActivity.this, "Please enter phone number and message", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Method to load data from SQLite database into RecyclerView
    private void loadDataFromDatabase() {
        Cursor cursor = dbHelper.getAllData();  // Get all data from database
        if (cursor.getCount() == 0) {
            // If no data is found, show a message
            Toast.makeText(this, "No data found", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                String item = cursor.getString(1);  // Get the item from column 1
                dataList.add(item);
            }
            dataAdapter.notifyDataSetChanged();  // Notify the adapter that data has changed
        }
        cursor.close();
    }

    // Implement the OnDataItemSelectedListener interface method
    @Override
    public void onDataItemSelected(String data) {
        // Handle the selected data (for example, update messageEditText)
        messageEditText.setText(data);  // Insert the selected data into the message input field
    }
}
