package com.example.cs360module3pedromartinez;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.Toast;
import java.util.ArrayList;
import android.database.Cursor;

public class DataDisplayActivity extends AppCompatActivity implements OnDataItemSelectedListener {

    // UI Elements
    private RecyclerView dataRecyclerView;
    private Button addDataButton;
    private Button goToSmsButton;
    private EditText inputDataEditText;
    private ArrayList<String> dataList;   // List to hold the data for RecyclerView
    private DataAdapter dataAdapter;      // Adapter for RecyclerView
    private DBHelper dbHelper;            // Database helper for SQLite operations

    private static final String TAG = "DataDisplayActivity"; // Tag for logging

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_display);

        // Initialize UI elements
        dataRecyclerView = findViewById(R.id.dataRecyclerView);
        addDataButton = findViewById(R.id.addDataButton);
        inputDataEditText = findViewById(R.id.inputDataEditText);
        goToSmsButton = findViewById(R.id.goToSmsButton);

        // Initialize database helper
        dbHelper = new DBHelper(this);

        // Setup data list and adapter
        dataList = new ArrayList<>();
        dataAdapter = new DataAdapter(dataList, dbHelper, this);  // Pass the listener

        // Setup RecyclerView with GridLayoutManager for the grid display
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 2); // 2 columns for grid
        dataRecyclerView.setLayoutManager(gridLayoutManager);
        dataRecyclerView.setAdapter(dataAdapter);

        // Load existing data from the database
        loadDataFromDatabase();

        // Handle Add Data button click
        addDataButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newData = inputDataEditText.getText().toString().trim();
                if (!newData.isEmpty()) {
                    // Insert new data into the database
                    if (dbHelper.insertData(newData)) {
                        // Add new data to the list
                        dataList.add(newData);
                        // Notify the adapter that the data has been added
                        dataAdapter.notifyItemInserted(dataList.size() - 1);
                        // Scroll to the newly added item
                        dataRecyclerView.scrollToPosition(dataList.size() - 1);
                        // Clear the input field
                        inputDataEditText.setText("");

                        // Logging for debugging purposes
                        Log.d(TAG, "Added new item: " + newData);
                        Toast.makeText(DataDisplayActivity.this, "Data added", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(DataDisplayActivity.this, "Error: Data could not be added", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(DataDisplayActivity.this, "Please enter some data", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Handle SMS Button click to navigate to SmsNotificationActivity
        goToSmsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DataDisplayActivity.this, SmsNotificationActivity.class);
                startActivity(intent);
            }
        });
    }

    // Method to load data from SQLite database into RecyclerView
    private void loadDataFromDatabase() {
        Cursor cursor = dbHelper.getAllData();  // Get all data from database
        if (cursor.getCount() == 0) {
            // If no data is found, show a message
            Toast.makeText(this, "No data found", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                String item = cursor.getString(1);  // Get the item from column 1
                dataList.add(item);
            }
            dataAdapter.notifyDataSetChanged();  // Notify the adapter that data has changed
        }
        cursor.close();
    }

    // Implement the onDataItemSelected method from the interface
    @Override
    public void onDataItemSelected(String data) {
        // Handle the item selection event here
        Toast.makeText(this, "Selected item: " + data, Toast.LENGTH_SHORT).show();
    }
}
