package com.example.cs360module3pedromartinez;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    // Database Name and Version
    public static final String DATABASE_NAME = "AppData.db";
    public static final int DATABASE_VERSION = 1;

    // User Table (for login)
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "ID";
    public static final String COL_USER_NAME = "USERNAME";
    public static final String COL_USER_PASSWORD = "PASSWORD";

    // Data Table (for data items in DataDisplayActivity)
    public static final String TABLE_DATA = "data";
    public static final String COL_DATA_ID = "ID";
    public static final String COL_DATA_ITEM = "ITEM";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users table
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME TEXT, PASSWORD TEXT)");

        // Create Data table
        db.execSQL("CREATE TABLE " + TABLE_DATA + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, ITEM TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older tables if they exist
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DATA);
        // Recreate tables
        onCreate(db);
    }

    // ------------------ User Table Methods ------------------

    // Method to insert a new user into the users table
    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_USER_NAME, username);
        contentValues.put(COL_USER_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, contentValues);
        return result != -1; // If result is -1, insertion failed
    }

    // Method to check if a user exists (for login verification)
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE USERNAME=? AND PASSWORD=?", new String[]{username, password});
        boolean exists = cursor.getCount() > 0; // If count > 0, user exists
        cursor.close();
        return exists;
    }

    // Method to check if a username already exists (for account creation)
    public boolean checkUsernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE USERNAME=?", new String[]{username});
        boolean exists = cursor.getCount() > 0; // If count > 0, username exists
        cursor.close();
        return exists;
    }

    // Method to update a user’s password
    public boolean updateUserPassword(String username, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_USER_PASSWORD, newPassword);
        int rows = db.update(TABLE_USERS, contentValues, "USERNAME = ?", new String[]{username});
        return rows > 0; // Return true if at least one row was updated
    }

    // Method to delete a user by username
    public boolean deleteUser(String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_USERS, "USERNAME = ?", new String[]{username});
        return rows > 0; // Return true if at least one row was deleted
    }

    // ------------------ Data Table Methods ------------------

    // Insert a new data item into the data table
    public boolean insertData(String item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_DATA_ITEM, item);
        long result = db.insert(TABLE_DATA, null, contentValues);
        return result != -1; // Return false if insertion failed
    }

    // Retrieve all data items from the data table
    public Cursor getAllData() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_DATA, null);
    }

    // Delete a data item by its ID
    public boolean deleteData(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_DATA, "ID = ?", new String[]{String.valueOf(id)});
        return rows > 0; // Return true if at least one row was deleted
    }

    // Update a data item by its ID
    public boolean updateData(int id, String newItem) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_DATA_ITEM, newItem);
        int rows = db.update(TABLE_DATA, contentValues, "ID = ?", new String[]{String.valueOf(id)});
        return rows > 0; // Return true if at least one row was updated
    }
}
