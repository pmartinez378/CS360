package com.example.cs360module3pedromartinez;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.text.Editable;
import android.text.TextWatcher;
import com.example.cs360module3pedromartinez.DBHelper;


public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button createAccountButton;
    private TextView textGreeting;

    private DBHelper dbHelper; // SQLite DB Helper

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize DBHelper
        dbHelper = new DBHelper(this);

        // Initialize UI elements
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);
        textGreeting = findViewById(R.id.textGreeting);

        // Set up TextWatchers to enable/disable the login button dynamically
        usernameEditText.addTextChangedListener(new LoginTextWatcher());
        passwordEditText.addTextChangedListener(new LoginTextWatcher());

        // Set up the login button click event
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleLogin();
            }
        });

        // Set up the create account button click event
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleCreateAccount();
            }
        });
    }

    // Custom TextWatcher to enable/disable the login button
    private class LoginTextWatcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            // No action needed before text changes
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            // Enable the login button if both username and password fields are not empty
            loginButton.setEnabled(!usernameEditText.getText().toString().trim().isEmpty() &&
                    !passwordEditText.getText().toString().trim().isEmpty());
        }

        @Override
        public void afterTextChanged(Editable s) {
            // No action needed after text changes
        }
    }

    // Method to handle login functionality
    private void handleLogin() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (!username.isEmpty() && !password.isEmpty()) {
            // Check if the username and password match in the database
            if (dbHelper.checkUser(username, password)) {
                textGreeting.setText("Hello, " + username + "! You are logged in.");
                Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();

                // Navigate to the next activity
                Intent intent = new Intent(MainActivity.this, DataDisplayActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(MainActivity.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to handle account creation functionality
    private void handleCreateAccount() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (!username.isEmpty() && !password.isEmpty()) {
            // Check if the username already exists
            if (dbHelper.checkUsernameExists(username)) {
                Toast.makeText(MainActivity.this, "Username already exists. Please choose another one.", Toast.LENGTH_SHORT).show();
            } else {
                // Add the username and password to the database
                if (dbHelper.insertUser(username, password)) {
                    Toast.makeText(MainActivity.this, "Account Created Successfully", Toast.LENGTH_SHORT).show();
                    textGreeting.setText("Account created for " + username + ".");

                    // Navigate to the next activity
                    Intent intent = new Intent(MainActivity.this, DataDisplayActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Error: Account creation failed", Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            Toast.makeText(MainActivity.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
        }
    }
}
