package com.example.cs360module3pedromartinez;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsNotificationActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    private EditText phoneNumberEditText;
    private EditText messageEditText;
    private Button sendSmsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notification);

        // Initialize UI elements
        phoneNumberEditText = findViewById(R.id.phoneNumberEditText);
        messageEditText = findViewById(R.id.messageEditText);
        sendSmsButton = findViewById(R.id.sendSmsButton);

        // Set up click listener for Send SMS button using lambda
        sendSmsButton.setOnClickListener(v -> {
            // Check if SMS permission is granted
            if (ContextCompat.checkSelfPermission(SmsNotificationActivity.this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, send the SMS
                sendSms();
            } else {
                // Request SMS permission with an explanation
                if (ActivityCompat.shouldShowRequestPermissionRationale(SmsNotificationActivity.this, Manifest.permission.SEND_SMS)) {
                    Toast.makeText(SmsNotificationActivity.this, "SMS permission is required to send messages.", Toast.LENGTH_LONG).show();
                }
                ActivityCompat.requestPermissions(SmsNotificationActivity.this,
                        new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
            }
        });
    }

    // Method to send SMS
    private void sendSms() {
        String phoneNumber = phoneNumberEditText.getText().toString().trim();
        String message = messageEditText.getText().toString().trim();

        if (!phoneNumber.isEmpty() && !message.isEmpty()) {
            if (isValidPhoneNumber(phoneNumber)) {
                SmsManager smsManager = SmsManager.getDefault();
                if (smsManager != null) {
                    smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                    Toast.makeText(this, "SMS sent successfully!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Failed to send SMS. Please try again later.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Please enter a valid phone number.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please enter a valid phone number and message.", Toast.LENGTH_SHORT).show();
        }
    }

    // Handle the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, send the SMS
                sendSms();
            } else {
                // Permission denied
                Toast.makeText(this, "Permission denied to send SMS", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Method to check if the phone number is valid (basic validation)
    private boolean isValidPhoneNumber(String phoneNumber) {
        // Basic validation to check if the phone number contains only digits and is of reasonable length
        return phoneNumber.matches("\\d{10,13}");
    }
}
