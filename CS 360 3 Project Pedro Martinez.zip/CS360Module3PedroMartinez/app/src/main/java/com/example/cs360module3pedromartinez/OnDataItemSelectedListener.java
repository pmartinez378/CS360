package com.example.cs360module3pedromartinez;

public interface OnDataItemSelectedListener {
    void onDataItemSelected(String data);
}
