package com.example.cs360module3pedromartinez;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import android.database.Cursor;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {

    // List to hold data to be displayed in RecyclerView
    private final ArrayList<String> dataList;
    private final DBHelper dbHelper;
    private final OnDataItemSelectedListener listener;

    // Constructor for DataAdapter
    public DataAdapter(ArrayList<String> dataList, DBHelper dbHelper, OnDataItemSelectedListener listener) {
        this.dataList = dataList;
        this.dbHelper = dbHelper;  // Store DBHelper for future use (e.g., deleting items)
        this.listener = listener;  // Store listener for item selection
    }

    // Inflate item_row.xml for each item in the RecyclerView
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row, parent, false);
        return new ViewHolder(view);
    }

    // Bind data to the TextView and handle button click for deletion
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        String data = dataList.get(position);
        holder.dataTextView.setText(data);

        // Set up a click listener for the item
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDataItemSelected(data);  // Notify the listener of the item selection
            }
        });

        // Set up a click listener for the delete button
        holder.deleteButton.setOnClickListener(v -> {
            int currentPosition = holder.getAdapterPosition();
            if (currentPosition != RecyclerView.NO_POSITION) {
                // Remove the item from the data list
                dataList.remove(currentPosition);
                // Notify the adapter that the item has been removed
                notifyItemRemoved(currentPosition);
            }
        });
    }

    // Return the size of the data list
    @Override
    public int getItemCount() {
        return dataList != null ? dataList.size() : 0;
    }

    // ViewHolder class to hold references to each item view
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView dataTextView;
        Button deleteButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // Initialize the TextView and Button from item_row.xml
            dataTextView = itemView.findViewById(R.id.dataTextView);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
